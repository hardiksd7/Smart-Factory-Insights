import streamlit as st
import pandas as pd
import pickle
import streamlit.components.v1 as components

# --- Page Configuration (Must be the first Streamlit command) ---
st.set_page_config(
    page_title="Predictive Maintenance AI Dashboard",
    page_icon="⚙️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# --- Object Loading Function ---
@st.cache_resource
def load_object(path):
    """A robust function to load pickled objects."""
    try:
        with open(path, 'rb') as f:
            return pickle.load(f)
    except FileNotFoundError:
        st.error(f"Error: The file '{path}' was not found. Please ensure it is in the same folder as app.py.")
        return None
    except Exception as e:
        st.error(f"Error loading {path}: {e}")
        return None

# --- Load all necessary objects ---
clf_model = load_object('classification_model.pkl')
reg_model = load_object('regression_model.pkl')
label_encoder = load_object('label_encoder.pkl')
scaler_params = load_object('scaler_params.pkl')

# --- Main App Title ---
st.title("⚙️ Predictive Maintenance AI Dashboard")
st.markdown("A sophisticated tool for predicting machine health and remaining useful life based on sensor data.")
st.markdown("---")

# --- Stop the app if essential files are missing ---
if not all([clf_model, reg_model, label_encoder, scaler_params]):
    st.warning("One or more essential model files could not be loaded. Please check the files and restart the app.")
    st.stop()

# --- Sidebar for User Input ---
with st.sidebar:
    st.header("Machine Parameters")
    st.markdown("Adjust the sliders and inputs to reflect the machine's current state.")
    
    # Use the loaded encoder to get the machine type options dynamically
    machine_type_options = label_encoder.classes_
    
    # Grouping inputs for better organization
    st.markdown("##### Core Identity & Vitals")
    machine_type = st.selectbox("Machine Type", options=machine_type_options)
    installation_year = st.number_input("Installation Year", 2000, 2040, 2015)
    operational_hours = st.slider("Operational Hours", 0, 100000, 50000)
    temperature_c = st.slider("Temperature (°C)", 15.0, 50.0, 25.5, help="Average temperature reading.")
    vibration_mms = st.slider("Vibration (mm/s)", 0.0, 10.0, 2.5, help="Average vibration level.")

    st.markdown("---")
    st.markdown("##### Consumables & Power")
    oil_level_pct = st.slider("Oil Level (%)", 0, 100, 80)
    coolant_level_pct = st.slider("Coolant Level (%)", 0, 100, 75)
    power_consumption_kw = st.slider("Power Consumption (kW)", 0.5, 10.0, 4.5)
    sound_db = st.slider("Sound (dB)", 60.0, 100.0, 75.0)
    
    st.markdown("---")
    st.markdown("##### Maintenance & History")
    last_maintenance_days = st.number_input("Last Maintenance (Days Ago)", 0, value=90)
    maintenance_history_count = st.number_input("Maintenance History Count", 0, value=5)
    failure_history_count = st.number_input("Failure History Count", 0, value=1)
    error_codes_last_30d = st.number_input("Error Codes (Last 30 Days)", 0, value=3)

    st.markdown("---")
    st.markdown("##### Specialized Sensors & AI")
    laser_intensity = st.slider("Laser Intensity", 80.0, 120.0, 100.0)
    hydraulic_pressure = st.slider("Hydraulic Pressure [bar]", 85.0, 135.0, 110.0)
    coolant_flow = st.slider("Coolant Flow [L/min]", 0.0, 2.0, 1.0)
    heat_index = st.slider("Heat Index", 20.0, 80.0, 45.0)
    ai_override_events = st.number_input("AI Override Events", 0, value=0)
    ai_supervision = st.selectbox("AI Supervision", (True, False), format_func=lambda x: 'Enabled' if x else 'Disabled')

# --- Data Preparation Function (The Core Logic) ---
def prepare_input_data(is_for_classification, rul_input=None, failure_input=None):
    """Prepares user input into a feature DataFrame 'X' for the models, perfectly matching the notebook."""
    base_data = {
        'Machine_Type': [machine_type], 'Installation_Year': [installation_year],
        'Operational_Hours': [operational_hours], 'Temperature_C': [temperature_c],
        'Vibration_mms': [vibration_mms], 'Sound_dB': [sound_db],
        'Oil_Level_pct': [oil_level_pct], 'Coolant_Level_pct': [coolant_level_pct],
        'Power_Consumption_kW': [power_consumption_kw], 'Last_Maintenance_Days_Ago': [last_maintenance_days],
        'Maintenance_History_Count': [maintenance_history_count], 'Failure_History_Count': [failure_history_count],
        'AI_Supervision': [ai_supervision], 'Error_Codes_Last_30_Days': [error_codes_last_30d],
        'Laser_Intensity': [laser_intensity], 'Hydraulic_Pressure_bar': [hydraulic_pressure],
        'Coolant_Flow_L_min': [coolant_flow], 'Heat_Index': [heat_index],
        'AI_Override_Events': [ai_override_events]
    }
    
    input_df = pd.DataFrame(base_data)
    input_df['Machine_Type'] = label_encoder.transform(input_df['Machine_Type'])
    input_df['AI_Supervision'] = input_df['AI_Supervision'].astype(int)

    if is_for_classification:
        input_df['Remaining_Useful_Life_days'] = [rul_input]
        training_cols = scaler_params['mean'].index
        X = input_df[training_cols]
        X_scaled = (X - scaler_params['mean']) / scaler_params['std']
        return X_scaled
    else: # Regression
        input_df['Failure_Within_7_Days'] = [int(failure_input)]
        return input_df

# --- Main Page Layout using Tabs ---
# Add a new tab for the Tableau dashboard
tab1, tab2, tab3 = st.tabs(["Failure Prediction (Classification)", "RUL Prediction (Regression)", "IoT Tableau Dashboard"])

with tab1:
    st.subheader("Predict Failure Within 7 Days")
    st.info("This model predicts the probability of machine failure in the near future based on the input parameters.", icon="💡")
    st.warning("This model requires a 'Remaining Useful Life' input due to data leakage during its training process. This is for demonstration purposes.", icon="⚠️")
    
    # Input for the leaked feature, placed logically with the prediction button
    rul_input_clf = st.number_input("Enter RUL (Required by Model)", 0, value=50, key="clf_rul")

    if st.button("Predict Failure", key="predict_failure_btn"):
        input_df_processed = prepare_input_data(is_for_classification=True, rul_input=rul_input_clf)
        
        with st.spinner('Analyzing data and running model...'):
            prediction = clf_model.predict(input_df_processed)[0]
            probability = clf_model.predict_proba(input_df_processed)[0][1]

        st.markdown("---")
        st.subheader("Prediction Result")
        col1, col2 = st.columns([2, 1])
        with col1:
            if prediction == 1:
                st.error("### Status: High Risk of Failure", icon="🚨")
                st.markdown("The model indicates a high probability of failure within 7 days. **Immediate inspection is recommended.**")
            else:
                st.success("### Status: Normal Operation", icon="✅")
                st.markdown("The model indicates the machine is operating within normal parameters and is unlikely to fail.")
        with col2:
            st.metric(label="Calculated Probability of Failure", value=f"{probability:.2%}")
        
        with st.expander("Show Processed Data Sent to Model (Scaled)"):
            st.dataframe(input_df_processed)

with tab2:
    st.subheader("Predict Remaining Useful Life (RUL)")
    st.info("This model estimates the number of days until the machine is likely to require maintenance or fail.", icon="💡")
    st.warning("This model requires a 'Has Failed?' input due to data leakage during its training process. This is for demonstration purposes.", icon="⚠️")
    
    # Input for the leaked feature
    failure_input_reg = st.selectbox("Has Failed? (Required by Model)", (False, True), key="reg_fail")

    if st.button("Predict RUL", key="predict_rul_btn"):
        input_df_processed = prepare_input_data(is_for_classification=False, failure_input=failure_input_reg)
        
        with st.spinner('Analyzing data and running model...'):
            reg_cols = reg_model.feature_names_in_
            prediction = reg_model.predict(input_df_processed[reg_cols])[0]

        st.markdown("---")
        st.subheader("Prediction Result")
        st.metric(label="Predicted Remaining Useful Life", value=f"{prediction:.1f} days")
        
        with st.expander("Show Processed Data Sent to Model (Unscaled)"):
            st.dataframe(input_df_processed[reg_cols])

with tab3:
    st.subheader("Live IoT Dashboard (Tableau)")
    st.info("This dashboard provides a live, interactive visualization of the IoT sensor data.")
    
    # URL with embed parameters to help with display
    tableau_url = "https://public.tableau.com/views/IoTTableau/Dashboard1?:embed=yes&:showVizHome=no&:tabs=yes&:toolbar=yes&:showAppBanner=false&:showShareOptions=false"

    # Create the iframe HTML
    iframe_html = f"""
    <iframe
        src="{tableau_url}"
        width="100%"
        height="800"
        allowfullscreen="true"
        frameborder="0">
    </iframe>
    """
    
    # Render the iframe using st.components.v1.html
    components.html(iframe_html, height=800, scrolling=True)